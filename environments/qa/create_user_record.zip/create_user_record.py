import boto3
import os

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(os.environ['USERS_TABLE'])

def lambda_handler(event, context):
    user_id = event['request']['userAttributes']['sub']
    email = event['request']['userAttributes']['email']
    
    table.put_item(
        Item={
            'user_id': user_id,
            'email': email,
            'created_at': event['request']['userAttributes']['email_verified']
        }
    )
    
    return event
